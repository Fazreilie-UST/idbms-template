from fastapi import APIRouter

from app.api.v1.endpoints import auth, stock, test

api_router = APIRouter()

api_router.include_router(test.router, tags=["test"])
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(stock.router)