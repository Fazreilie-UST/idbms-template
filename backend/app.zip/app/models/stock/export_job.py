from datetime import datetime

from sqlalchemy import Column, Integer, DateTime, ForeignKey, Enum as SqlEnum, String
from sqlalchemy.orm import relationship

from app.db.base import Base
from app.models.stock.enums import ImportExportTableName, FileType


class ExportJob(Base):
    __tablename__ = "export_job"

    export_job_id = Column(Integer, primary_key=True, index=True)

    table_name = Column(SqlEnum(ImportExportTableName, name="export_table_name_enum"), nullable=False)
    file_type = Column(SqlEnum(FileType, name="export_file_type_enum"), nullable=False)
    filename = Column(String, nullable=True)

    total_rows = Column(Integer, nullable=False, default=0)
    status = Column(String, nullable=False, default="completed")
    message = Column(String, nullable=True)

    exported_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    exported_by = relationship("User", back_populates="export_jobs")