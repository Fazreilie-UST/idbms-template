from sqlalchemy.orm import Session
from app.models.stock.export_job import ExportJob

class DimExportJobRepository:
    def __init__(self, db: Session):
        self.db = db

    def list(self, skip: int = 0, limit: int = 100):
        return self.db.query(ExportJob).offset(skip).limit(limit).all()