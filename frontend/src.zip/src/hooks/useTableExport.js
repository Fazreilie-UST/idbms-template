import { useCallback, useState } from "react";
import { message } from "antd";
import { fetchAllPaginatedRows } from "../utils/fetchAllPaginatedRows";
import { logExportJob } from "../services/stock_service";
import { useAuthStore } from "../store/useAuthStore";

const DEFAULT_EXPORT_BATCH_SIZE = 500;

export default function useTableExport(
  fetchPageFn,
  {
    tableName,
    batchSize = DEFAULT_EXPORT_BATCH_SIZE,
    buildFilename,
  }
) {
  const [exporting, setExporting] = useState(false);
  const token = useAuthStore((state) => state.token);

  const getExportRows = useCallback(async () => {
    return fetchAllPaginatedRows(fetchPageFn, batchSize);
  }, [fetchPageFn, batchSize]);

  const runExport = useCallback(
    async (fileType, exportFn, successMessage, errorMessage) => {
      try {
        setExporting(true);

        const rows = await getExportRows();
        const filename = buildFilename?.(fileType, rows) ?? null;

        await exportFn(rows);

        await logExportJob(
          {
            table_name: tableName,
            file_type: fileType,
            filename,
            total_rows: rows.length,
            status: "completed",
          },
          token
        );

        message.success(successMessage);
      } catch (error) {
        message.error(error?.message || errorMessage || "Export failed");
      } finally {
        setExporting(false);
      }
    },
    [getExportRows, tableName, buildFilename, token]
  );

  return {
    exporting,
    getExportRows,
    runExport,
  };
}