from fastapi import APIRouter, Depends, Form, Query, UploadFile, File
from sqlalchemy.orm import Session

from app.db import get_db
from app.schemas.stock import (
    PaginatedResponse,
    ImportResultResponse,
    DimStockOut,
    DimDateOut,
    DimMetricOut,
    DimStatementOut,
    FactFinancialValueOut,
    FactPreviewOut,
    StockStatementExplorerRequest,
    StockStatementExplorerResponse,
    ExportLogRequest,
)
from app.services.stock.stock_service import StockService
from app.services.stock.dimension_import_service import DimensionImportService
from app.services.stock.fact_import_service import FinancialFactsImportService
from app.services.stock.stock_statement_explorer_service import (
    StockStatementExplorerService,
)
from app.services.stock.query_metadata import ALLOWED_COLUMNS
from app.models.stock.dim_stock import DimStock
from app.models.stock.dim_date import DimDate
from app.models.stock.dim_statement import DimStatement
from app.models.stock.dim_metric import DimMetric
from app.models.stock.fact_financial_values import FactFinancialValues
from app.models.stock.import_job import ImportJob
from app.models.stock.export_job import ExportJob
from app.models.auth.user import User
from app.core.dependencies import get_current_user


router = APIRouter(prefix="/stocks", tags=["stocks"])


@router.get("/master", response_model=PaginatedResponse[DimStockOut])
def get_stock_master(
    skip: int = 0,
    limit: int = Query(100, le=500),
    sort_by: str | None = Query(None),
    sort_order: str = Query("asc"),
    db: Session = Depends(get_db),
):
    return StockService(db).get_stock_master(
        skip=skip,
        limit=limit,
        sort_by=sort_by,
        sort_order=sort_order,
    )


@router.get("/dates", response_model=PaginatedResponse[DimDateOut])
def get_dates(
    skip: int = 0,
    limit: int = Query(100, le=500),
    db: Session = Depends(get_db),
):
    return StockService(db).get_dates(skip=skip, limit=limit)


@router.get("/statements", response_model=PaginatedResponse[DimStatementOut])
def get_statements(
    skip: int = 0,
    limit: int = Query(100, le=500),
    db: Session = Depends(get_db),
):
    return StockService(db).get_statements(skip=skip, limit=limit)


@router.get("/metrics", response_model=PaginatedResponse[DimMetricOut])
def get_metrics(
    skip: int = 0,
    limit: int = Query(100, le=500),
    db: Session = Depends(get_db),
):
    return StockService(db).get_metrics(skip=skip, limit=limit)


@router.get("/facts", response_model=PaginatedResponse[FactFinancialValueOut])
def get_facts(
    skip: int = 0,
    limit: int = Query(100, le=500),
    sort_by: str | None = Query(None),
    sort_order: str = Query("asc"),
    db: Session = Depends(get_db),
):
    return StockService(db).get_facts(
        skip=skip,
        limit=limit,
        sort_by=sort_by,
        sort_order=sort_order,
    )


@router.get("/facts/preview", response_model=PaginatedResponse[FactPreviewOut])
def get_facts_preview(
    skip: int = 0,
    limit: int = Query(100, le=500),
    db: Session = Depends(get_db),
):
    base_query = (
        db.query(
            FactFinancialValues.stock_id,
            DimStock.stock_code,
            DimStock.stock_name,
            FactFinancialValues.metric_id,
            DimMetric.metric_name,
            FactFinancialValues.statement_id,
            DimStatement.statement_name,
            FactFinancialValues.date_id,
            DimDate.full_date,
            FactFinancialValues.value,
        )
        .join(DimStock, FactFinancialValues.stock_id == DimStock.stock_id)
        .join(DimMetric, FactFinancialValues.metric_id == DimMetric.metric_id)
        .join(DimStatement, FactFinancialValues.statement_id == DimStatement.statement_id)
        .join(DimDate, FactFinancialValues.date_id == DimDate.date_id)
    )

    total = base_query.count()
    rows = base_query.offset(skip).limit(limit).all()

    items = [
        {
            "stock_id": r.stock_id,
            "stock_code": r.stock_code,
            "stock_name": r.stock_name,
            "metric_name": r.metric_name,
            "statement_name": r.statement_name,
            "full_date": r.full_date,
            "value": r.value,
        }
        for r in rows
    ]

    return {
        "items": items,
        "total": total,
        "skip": skip,
        "limit": limit,
    }


@router.get("/query-builder/metadata")
def get_query_builder_metadata():
    return {
        "tables": list(ALLOWED_COLUMNS.keys()),
        "columns": ALLOWED_COLUMNS,
        "joins": {
            "base_table": "fact_financial_values",
            "supported_dimension_tables": [
                "dim_stock",
                "dim_date",
                "dim_metric",
                "dim_statement",
            ],
        },
        "operators": ["=", "!=", ">", ">=", "<", "<=", "in", "like", "ilike"],
        "aggregations": ["sum", "avg", "min", "max", "count"],
    }


@router.post("/explorer/preview", response_model=StockStatementExplorerResponse)
def preview_stock_statement_explorer(
    payload: StockStatementExplorerRequest,
    db: Session = Depends(get_db),
):
    return StockStatementExplorerService(db).preview(payload)


@router.post("/facts/import-csv", response_model=ImportResultResponse)
async def import_financial_facts_csv(
    file: UploadFile = File(...),
    dry_run: bool = Form(False),
    replace_all: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    replace_all_bool = str(replace_all).lower() in ("true", "1", "yes", "on")

    return await FinancialFactsImportService(db).import_csv(
        file=file,
        dry_run=dry_run,
        replace_all=replace_all_bool,
        imported_by_id=current_user.user_id,
    )


@router.post("/master/import-csv", response_model=ImportResultResponse)
async def import_dim_stock_csv(
    file: UploadFile = File(...),
    dry_run: str = Form("false"),
    replace_all: str = Form("false"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    dry_run_bool = str(dry_run).lower() in ("true", "1", "yes", "on")
    replace_all_bool = str(replace_all).lower() in ("true", "1", "yes", "on")
    return await DimensionImportService(db).import_csv(
        table_name="dim_stock",
        file=file,
        dry_run=dry_run_bool,
        replace_all=replace_all_bool,
        imported_by_id=current_user.user_id,
    )


@router.post("/dates/import-csv", response_model=ImportResultResponse)
async def import_dim_date_csv(
    file: UploadFile = File(...),
    dry_run: str = Form("false"),
    replace_all: str = Form("false"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    dry_run_bool = str(dry_run).lower() in ("true", "1", "yes", "on")
    replace_all_bool = str(replace_all).lower() in ("true", "1", "yes", "on")
    return await DimensionImportService(db).import_csv(
        table_name="dim_date",
        file=file,
        dry_run=dry_run_bool,
        replace_all=replace_all_bool,
        imported_by_id=current_user.user_id,
    )


@router.post("/statements/import-csv", response_model=ImportResultResponse)
async def import_dim_statement_csv(
    file: UploadFile = File(...),
    dry_run: str = Form("false"),
    replace_all: str = Form("false"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    dry_run_bool = str(dry_run).lower() in ("true", "1", "yes", "on")
    replace_all_bool = str(replace_all).lower() in ("true", "1", "yes", "on")
    return await DimensionImportService(db).import_csv(
        table_name="dim_statement",
        file=file,
        dry_run=dry_run_bool,
        replace_all=replace_all_bool,
        imported_by_id=current_user.user_id,
    )


@router.post("/metrics/import-csv", response_model=ImportResultResponse)
async def import_dim_metric_csv(
    file: UploadFile = File(...),
    dry_run: str = Form("false"),
    replace_all: str = Form("false"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    dry_run_bool = str(dry_run).lower() in ("true", "1", "yes", "on")
    replace_all_bool = str(replace_all).lower() in ("true", "1", "yes", "on")
    return await DimensionImportService(db).import_csv(
        table_name="dim_metric",
        file=file,
        dry_run=dry_run_bool,
        replace_all=replace_all_bool,
        imported_by_id=current_user.user_id,
    )


@router.get("/imports/history")
def get_import_history(
    skip: int = 0,
    limit: int = Query(50, le=200),
    db: Session = Depends(get_db),
):
    query = db.query(ImportJob).order_by(ImportJob.created_at.desc())
    total = query.count()
    items = query.offset(skip).limit(limit).all()

    return {
        "items": [
            {
                "import_job_id": item.import_job_id,
                "table_name": item.table_name,
                "filename": item.filename,
                "dry_run": item.dry_run,
                "inserted": item.inserted,
                "updated": item.updated,
                "unchanged": item.unchanged,
                "status": item.status,
                "message": item.message,
                "created_at": item.created_at.isoformat() if item.created_at else None,
            }
            for item in items
        ],
        "total": total,
        "skip": skip,
        "limit": limit,
    }

@router.post("/exports/log")
def log_export_job(
    payload: ExportLogRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    job = ExportJob(
        table_name=payload.table_name,
        file_type=payload.file_type.lower(),
        filename=payload.filename,
        total_rows=payload.total_rows,
        status=payload.status,
        message=payload.message,
        exported_by_id=current_user.user_id,
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    return {
        "export_job_id": job.export_job_id,
        "message": "Export logged successfully",
    }

@router.get("/exports/history")
def get_export_history(
    skip: int = 0,
    limit: int = Query(50, le=200),
    db: Session = Depends(get_db),
):
    query = db.query(ExportJob).order_by(ExportJob.created_at.desc())
    total = query.count()
    items = query.offset(skip).limit(limit).all()

    return {
        "items": [
            {
                "export_job_id": item.export_job_id,
                "table_name": item.table_name,
                "filename": item.filename,
                "file_type": item.file_type,
                "total_rows": item.total_rows,
                "status": item.status,
                "message": item.message,
                "created_at": item.created_at.isoformat() if item.created_at else None,
            }
            for item in items
        ],
        "total": total,
        "skip": skip,
        "limit": limit,
    }