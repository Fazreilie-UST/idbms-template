from pydantic import BaseModel, Field

class ExportLogRequest(BaseModel):
    table_name: str
    file_type: str = Field(pattern="^(json|csv|pdf|xlsx)$")
    filename: str | None = None
    total_rows: int = 0
    status: str = "completed"
    message: str | None = None